﻿//******************************************************
// File: MainWindow.xaml.cs
//
// Purpose: Contains partial class of MainWindow
//          Includes event handlers for the wpf controls
//          Includes function to ShowTableToWindow() -> showing server table Stations
//
// Written By: Reina Vencer 
//
// Compiler: Visual Studio 2015
//
//******************************************************

using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using CLASS_LIBRARY;
using System.Collections.ObjectModel;

namespace Assignment_4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region private member variables
        private StationCollection sc;        
        private BranchSchedule bs;
        private TrainCollection tc;
        #endregion


        public MainWindow()//constructor
        {
            InitializeComponent();
        }

        //****************************************************
        // Method: private void MenuItem_Click(object sender, RoutedEventArgs e)
        //
        // Purpose: Event handler for About MenuItem Click
        //****************************************************
        private void MenuItem_Click(object sender, RoutedEventArgs e)//About
        {
            MessageBox.Show("Train Schedule \nVersion 3.0 \nWritten By: Reina Vencer", "About");
        }


        //****************************************************
        // Method: private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        //
        // Purpose: Event handler for Import Stations From JSON MenuItem Click
        //****************************************************
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)//Import Stations From JSON
        {
            string connString = @"server = (localdb)\MSSQLLocalDB;" +
            "integrated security = SSPI;" +
            "database = TrainSchedule;" +
            "MultipleActiveResultSets = True";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title ="Import Stations From JSON";
            dlg.InitialDirectory = Directory.GetCurrentDirectory();
            dlg.Filter = "JSON files (*.json)|*.json";

            if (dlg.ShowDialog() == true)
            {

                FileStream reader = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read);

                DataContractJsonSerializer inputSerializer;
                inputSerializer = new DataContractJsonSerializer(typeof(StationCollection));

                sc = (StationCollection)inputSerializer.ReadObject(reader);
                reader.Close();

                SqlConnection sqlConn;
                sqlConn = new SqlConnection(connString);
                sqlConn.Open();

                string truncateSQL = "TRUNCATE TABLE Stations";
                SqlCommand truncate = new SqlCommand(truncateSQL, sqlConn);
                int rowsAffectedByTruncate = truncate.ExecuteNonQuery();

                foreach (Station s in sc.stations)
                {
                    string sql = string.Format(
                         "INSERT INTO Stations" +
                         "(StationID, Name, Location, FareZone, MileageToPenn, PicFilename) Values" +
                         "('{0}','{1}','{2}','{3}','{4}','{5}')", s.id,s.name,s.location,s.fareZone,s.mileageToPenn,s.picFilename);
                    
                    SqlCommand command = new SqlCommand(sql, sqlConn);
                    int rowsAffected = command.ExecuteNonQuery();
                }

                ShowTableToWindow();

            }
        }


        //****************************************************
        // Method: private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        //
        // Purpose: Event handler for Open Branch Schedule MenuItem Click
        //****************************************************
        private void MenuItem_Click_2(object sender, RoutedEventArgs e)//Open Branch Schedule
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Branch Schedule From JSON";
            dlg.InitialDirectory = Directory.GetCurrentDirectory();
            dlg.Filter = "JSON files (*.json)|*.json";

            if (dlg.ShowDialog() == true)
            {

                FileStream reader = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read);

                DataContractJsonSerializer inputSerializer;
                inputSerializer = new DataContractJsonSerializer(typeof(BranchSchedule));

                bs = (BranchSchedule)inputSerializer.ReadObject(reader);
                reader.Close();

                textBoxBranchId.Text = Convert.ToString(bs.branchId);

                foreach (int trainID in bs.trainIds)
                {
                    listBoxBranchTrainIds.Items.Add(trainID);
                }

                string trainsFilename = "TrainCollection2.json";

                FileStream reader2 = new FileStream(trainsFilename, FileMode.Open, FileAccess.Read);

                DataContractJsonSerializer inputSerializer2;
                inputSerializer2 = new DataContractJsonSerializer(typeof(TrainCollection));

                tc = (TrainCollection)inputSerializer2.ReadObject(reader2);
                reader2.Close();              

            }
        }


        //****************************************************
        // Method: private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        //
        // Purpose: Event handler for Exit MenuItem Click; Closes the window
        //****************************************************
        private void MenuItem_Click_3(object sender, RoutedEventArgs e)//Exit
        {
            Close();
        }


        //****************************************************
        // Method: private void Window_Loaded(object sender, RoutedEventArgs e)
        //
        // Purpose: Event handler for Window_Loaded event; Shows table from database to All Stations tab
        //          Links icon image path to icon window control
        //****************************************************
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var path = System.IO.Path.Combine(Environment.CurrentDirectory, "trainIcon.png");
            var uri = new Uri(path);
            var bitmap = new BitmapImage(uri);
            this.Icon = bitmap;

            ShowTableToWindow();
        }


        //****************************************************
        // Method: private void ShowTableToWindow()
        //
        // Purpose: Method to read data from Stations table in the database TrainSchedule
        //          Add data to station collection variable and output to appropriate wpf controls
        //****************************************************
        private void ShowTableToWindow()
        {
            string connString = @"server = (localdb)\MSSQLLocalDB;" +
            "integrated security = SSPI;" +
            "database = TrainSchedule;" +
            "MultipleActiveResultSets = True";

            SqlConnection sqlConn;
            sqlConn = new SqlConnection(connString);

            sqlConn.Open(); // Open the connection

            string sql = "SELECT * FROM Stations";
            SqlCommand command = new SqlCommand(sql, sqlConn);

            // Retrieve the data from the database
            SqlDataReader reader = command.ExecuteReader();
                      
       
            int fieldCount = reader.FieldCount;
            sc = new StationCollection();

            while (reader.Read())
            {
                Station s = new Station();
                s.id = reader.GetInt32(0);
                s.name = reader.GetString(1);
                s.location = reader.GetString(2);
                s.fareZone = Convert.ToInt32(reader.GetString(3));
                s.mileageToPenn = Convert.ToDouble(reader.GetDecimal(4));
                s.picFilename = reader.GetString(5);

                sc.stations.Add(s);
                listBoxStationName.Items.Add(s.name);

            }//end of while

            

        }//end of method


        //****************************************************
        // Method: private void listBoxStationName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //
        // Purpose: Even handler for selecting an item in listBoxStationName
        //****************************************************
        private void listBoxStationName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            string name = (string) e.AddedItems[0];

            Station s = sc.FindStation(name);

            textBoxName.Text = s.name;
            textBoxId.Text = Convert.ToString(s.id);
            textBoxLocation.Text = s.location;
            textBoxFareZone.Text = Convert.ToString(s.fareZone);
            textBoxMileageToPenn.Text = Convert.ToString(s.mileageToPenn);
            LoadImage(s.picFilename);
            

        }


        //****************************************************
        // Method: private void listBoxBranchTrainIds_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //
        // Purpose: Event handler for selected item in listBoxBranchTrainIds 
        //****************************************************
        private void listBoxBranchTrainIds_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            listViewStationArrivals.Items.Clear();

            int id = (int)e.AddedItems[0];

            Train t = tc.FindTrain(id);

            foreach (StationArrival sa in t.stationArrivals)
            {
                listViewStationArrivals.Items.Add(sa);
            }
                     
    
        }

        //****************************************************
        // Method: private void LoadImage(string filename)
        //
        // Purpose: Method to load image to Image control from a filename
        //****************************************************
        private void LoadImage(string filename)
        {         
           
            var path = System.IO.Path.Combine(Environment.CurrentDirectory,filename);
            var uri = new Uri(path);
            var bitmap = new BitmapImage(uri);

            image.Source = bitmap;
        }

    }//end of class
}//end of namespace
